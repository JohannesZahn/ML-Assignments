function [histo] = f4b(wuerfe)

histo = histogram(wuerfe).Values;

end

