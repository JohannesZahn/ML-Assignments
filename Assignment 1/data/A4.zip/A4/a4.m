clc
% a
dice_rolls = f4a();
%% b
histo = f4b(dice_rolls);
%% c
rho = f4c(dice_rolls,histo);
%% d
F = f4d(rho);
%% e
sample = f4e(F,unifrnd(0,1))





