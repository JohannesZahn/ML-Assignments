function [wuerfe] = f4a()

wuerfe = csvread('wuerfel.csv');

end
